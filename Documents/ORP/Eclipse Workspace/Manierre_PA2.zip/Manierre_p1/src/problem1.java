import java.util.Scanner;

public class problem1 {

	public static void main(String[] args) 
	{
		Scanner scnr = new Scanner(System.in);
		int userNum;
		int onesDigit;
		int tensDigit;
		int hunDigit;
		int thouDigit;
		int temp;
		
		
		System.out.println("Enter your 4 digit integer to be encrypted");
		userNum = scnr.nextInt();
		
		onesDigit = userNum % 10;    
		onesDigit = (onesDigit + 7) % 10;
		temp = userNum / 10;				// this line gets rid of ones digit
		
		
		tensDigit = (temp % 10);
		tensDigit = (tensDigit + 7) % 10;
		temp = temp / 10;

		
		
		hunDigit = (temp % 10);
		hunDigit = (hunDigit + 7) % 10;
		temp = temp / 10;

		
		thouDigit = (temp % 10);
		thouDigit = (thouDigit + 7) % 10;
	
		
											// swap ones digit with hundreds
											// swap tens with thousands
			

		
		System.out.println("Your encrypted number is:");
		System.out.print(tensDigit);
		System.out.print(onesDigit);
		System.out.print(thouDigit);
		System.out.println(hunDigit);
		


	}

}
