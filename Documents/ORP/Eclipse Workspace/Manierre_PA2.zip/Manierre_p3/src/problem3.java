import java.util.Scanner;

public class problem3 {

	public static void main(String[] args)
	{
		Scanner scnr = new Scanner(System.in);
		int i;
		int j;
		int numPartic; // number of participants for survey
		
		String[] topicsArray = { "Italian food", "The tax rate", "Exotic cars ", "Bicycles    ", "Pollution   " };	
		int responses[][] = {{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},};
		
		
		// take inputs
		System.out.println("Enter number of participants.");
		numPartic = scnr.nextInt();
		
		System.out.println("Rate the following topic's importance to you from 1 to 10.");
		System.out.println("10 being the most important, one being the least.\n");
		
		while (numPartic > 0) 
		{
			for (i = 0; i < 5; ++i) 
			{
				System.out.println(topicsArray[i] + "\n");
				responses[i][scnr.nextInt() - 1] ++;	
			}
		
			--numPartic;
		}
		
		System.out.println("\nResults: \n");
		System.out.println("Importance label:      " + "1 2 3 4 5 6 7 8 9 10\n");
		
		// Print results
		for(i = 0; i < 5; i++)
		{
			System.out.print(topicsArray[i]+ "           ");
			for(j = 0; j < 10; j++)
			{
				System.out.print("\n" + responses[i][j] + " ");
			}
			System.out.print("\n\n");
		}
	
	}

}
