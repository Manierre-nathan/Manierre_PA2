import java.util.Scanner;

public class Problem2 {

	public static void main(String[] args) 
	{
		//							BMI CALCULATOR
		//
		
		Scanner scnr = new Scanner(System.in);
		int weightP;	// weight in pounds
		int weightK;	// weight in kilos
		int heightM;	// meters
		int heightI;	// inches
		int bmiS;		// standard
		int bmiM;		// metric
		int selectForm;
		
		
		System.out.println("Enter '1' for BMI in metic, or enter '2' for BMI in Standard.");
		selectForm = scnr.nextInt();
		
		
		if (selectForm == 1)
		{
			
			System.out.println("Enter weight in kilograms.");
			weightK = scnr.nextInt();
			System.out.println("Enter height in meters.");
			heightM = scnr.nextInt();
			
			bmiM = weightK/(heightM * heightM);
			System.out.println("\nBMI = " + bmiM);			//user BMI
			
			System.out.println("\nUnderweight = < 18.5");
			System.out.println("Normal weight = 18.5–24.9");
			System.out.println("Overweight = 25–29.9");
			System.out.println("Obesity = BMI of 30 or greater");
			
		}
		
		if (selectForm == 2)
		{
			
			System.out.println("Enter weight in pounds.");
			weightP = scnr.nextInt();
			System.out.println("Enter height in inches.");
			heightI = scnr.nextInt();
			
			bmiS = (703 * weightP) / (heightI * heightI);
			System.out.println("BMI = " + bmiS);			//user BMI
			
			System.out.println("Underweight = < 18.5");
			System.out.println("Normal weight = 18.5–24.9");
			System.out.println("Overweight = 25–29.9");
			System.out.println("Obesity = BMI of 30 or greater");
			
		
		}
		
		

	}

}
